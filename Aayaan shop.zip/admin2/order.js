const Orders = [
    {
    productName: 'jeans', 
     productNumber: '85631',
     paymentStatus: 'Due', 
     shipping: 'Pending'
    }, 
    {
    productName: 'Black Shirt' ,
     productNumber: '36378',
     paymentStatus: 'Refunded',
      shipping: 'Declined'
    }, 
    {
    productName: 'Jacket' ,
    productNumber: '49347', 
    paymentStatus: 'Due', 
    shipping: 'Pending'
    }, 
    {
        productName: 'Formal', 
        productNumber: '96996', 
        paymentStatus: 'Paid', 
        shipping: 'Delivered',
    },
    {
    
    productName: 'Suit', 
    productNumber: '22821', 
    paymentStatus: 'Paid',
     shipping: 'Delivered'
    },

    {
    
        productName: 'Coat', 
        productNumber: '22821', 
        paymentStatus: 'Paid',
         shipping: 'Delivered'
        },

     {
    
            productName: 'Blazzer', 
            productNumber: '22821', 
            paymentStatus: 'Paid',
             shipping: 'Delivered'
            },
    
]